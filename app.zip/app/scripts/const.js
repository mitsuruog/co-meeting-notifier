(function() {
  'use strict';
  window.comeetingConfig = {
    OAUTH_CONSUMER_KEY: '845321a155cf3e9b52abe24bc6a2b2e2a165300c43fc33c69b9e54c99094407b',
    OAUTH_CONSUMER_SECRET: '4d27b6dee2d438050bc14d472fcf117c55b4231a9aebb090a58d5f3a5e29cf6f',
    APPLICATION_ID: 'gcncenlmfhkngpkgafognfofpanojolb'
  };
  window.comeetingConfig.URL = {
    REDIRECT: 'chrome-extension://' + window.comeetingConfig.APPLICATION_ID + '/callback.html',
    AUTHORIZE: 'https://www.co-meeting.com/oauth/authorize',
    TOKEN: 'https://www.co-meeting.com/oauth/token',
    FETCH: 'https://www.co-meeting.com/api/v1/groups/my',
    ME: 'https://www.co-meeting.com/api/v1/users/me'
  };
  window.comeetingConfig.BACK_GROUND = {
    COLOR_BLUE: [65, 131, 196, 255],
    COLOR_RED: [166, 41, 41, 255],
    UPDATE_INTERVAL: 1
  };
})();
